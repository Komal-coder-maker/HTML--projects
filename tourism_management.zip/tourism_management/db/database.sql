
            CREATE DATABASE tourism_management;

            USE tourism_management;

            CREATE TABLE users (
                user_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100),
                password VARCHAR(100),
                contact VARCHAR(15)
            );

            CREATE TABLE destinations (
                destination_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                location VARCHAR(100),
                description TEXT,
                image VARCHAR(255)
            );

            CREATE TABLE packages (
                package_id INT AUTO_INCREMENT PRIMARY KEY,
                destination_id INT,
                title VARCHAR(100),
                description TEXT,
                price DECIMAL(10, 2),
                duration VARCHAR(50),
                FOREIGN KEY (destination_id) REFERENCES destinations(destination_id)
            );

            CREATE TABLE bookings (
                booking_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                package_id INT,
                booking_date DATETIME,
                status ENUM('Pending', 'Confirmed', 'Cancelled'),
                payment_status ENUM('Pending', 'Paid'),
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (package_id) REFERENCES packages(package_id)
            );

            CREATE TABLE admin (
                admin_id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50),
                password VARCHAR(100)
            );
            